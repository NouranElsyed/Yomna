import React, { useEffect, useRef, useState } from "react";

/**
 * WeddingInvite
 * -------------
 * تحويل كامل لصفحة دعوة الزفاف من HTML/CSS/JS إلى مكوّن React واحد.
 * كل التصميم والأنيميشن (شاشة الفتح، القلوب المتساقطة، العد التنازلي،
 * فورم تأكيد الحضور) بنفس السلوك الأصلي 100%.
 *
 * الاستخدام:
 *   import WeddingInvite from "./WeddingInvite";
 *   <WeddingInvite
 *     groomName="أحمد"
 *     brideName="سارة"
 *     weddingDateISO="2025-11-15T19:00:00"
 *     venueName="قاعة الأمير الملكية"
 *     venueAddress="شارع النيل، القاهرة، مصر"
 *     mapUrl="https://maps.google.com"
 *   />
 */

const STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Aref+Ruqaa:wght@400;700&display=swap');

  .wi-root{
    --burgundy:#5e1a24;
    --burgundy-dark:#3d1017;
    --gold:#b08d4f;
    --gold-light:#d4af7a;
    --cream:#faf6ee;
  }

  .wi-root *{box-sizing:border-box;}

  .wi-root{
    font-family:'Amiri', serif;
    color:var(--burgundy-dark);
    min-height:100%;
    display:flex;
    justify-content:center;
    align-items:flex-start;
    overflow-x:hidden;
    background: linear-gradient(180deg,#f3ece0 0%, #eee3d0 100%);
    position:relative;
  }

  /* ===================== COVER SCREEN ===================== */
  .wi-coverScreen{
    position:fixed;
    inset:0;
    z-index:100;
    display:flex;
    align-items:center;
    justify-content:center;
    background: radial-gradient(ellipse at 50% 30%, #7a1f2c 0%, var(--burgundy-dark) 65%, #2a0a0f 100%);
    overflow:hidden;
    transition:opacity 0.6s ease, visibility 0.6s ease;
    padding:20px;
  }
  .wi-coverScreen.wi-hidden{
    opacity:0;
    visibility:hidden;
    pointer-events:none;
  }

  .wi-heartsBg{
    position:absolute;
    inset:0;
    overflow:hidden;
    pointer-events:none;
  }
  .wi-floatHeart{
    position:absolute;
    color:var(--gold-light);
    opacity:0.35;
    top:-10%;
    animation: wiFallHeart linear infinite;
    filter:drop-shadow(0 0 4px rgba(212,175,122,0.3));
  }
  @keyframes wiFallHeart{
    0%{ transform:translateY(-10vh) translateX(0) rotate(0deg); opacity:0; }
    10%{ opacity:0.45; }
    90%{ opacity:0.35; }
    100%{ transform:translateY(110vh) translateX(var(--drift,20px)) rotate(25deg); opacity:0; }
  }

  .wi-coverCard{
    max-width:480px;
    width:100%;
    background:var(--cream);
    border-radius:14px;
    box-shadow:0 25px 70px rgba(0,0,0,0.5);
    position:relative;
    padding:56px 30px 40px;
    text-align:center;
    border:1px solid #e3d6bd;
    z-index:2;
    transform-origin:center center;
    transition:transform 0.55s cubic-bezier(.55,0,.55,1), opacity 0.5s ease;
  }
  .wi-coverCard.wi-opening{
    transform:scale(0.15);
    opacity:0;
  }

  .wi-heartBadge{
    width:64px;
    height:64px;
    border-radius:50%;
    background:radial-gradient(circle at 35% 30%, var(--burgundy) 0%, var(--burgundy-dark) 100%);
    display:flex;
    align-items:center;
    justify-content:center;
    position:absolute;
    top:-32px;
    left:50%;
    transform:translateX(-50%);
    box-shadow:0 8px 20px rgba(94,26,36,0.4);
    animation:wiPulseHeart 2.4s ease-in-out infinite;
  }
  .wi-heartBadge svg{ width:26px; height:26px; fill:#fff; }
  @keyframes wiPulseHeart{
    0%,100%{ transform:translateX(-50%) scale(1); }
    50%{ transform:translateX(-50%) scale(1.08); }
  }

  .wi-coverNames{
    font-family:'Aref Ruqaa', serif;
    font-size:2.5rem;
    color:var(--burgundy);
    line-height:1.35;
    margin-top:26px;
  }
  .wi-coverAmp{
    display:block;
    font-size:1.1rem;
    color:var(--burgundy);
    margin:0;
    font-family:'Amiri', serif;
  }

  .wi-coverDivider{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    margin:16px 0 14px;
  }
  .wi-coverDivider .wi-line{
    width:52px;
    height:1px;
    background:var(--gold);
    opacity:0.6;
  }
  .wi-coverDivider .wi-dot{ color:var(--gold); font-size:0.85rem; }

  .wi-coverDate{
    color:#8a6a45;
    font-size:1.05rem;
    letter-spacing:0.5px;
    margin-bottom:18px;
    font-family:'Amiri', serif;
  }

  .wi-coverInviteTxt{
    color:#9c8460;
    font-size:1rem;
    margin-bottom:26px;
  }

  .wi-openBtn{
    display:inline-block;
    padding:13px 48px;
    background:linear-gradient(135deg,var(--burgundy),var(--burgundy-dark));
    color:var(--gold-light);
    border:none;
    border-radius:30px;
    font-size:1.05rem;
    font-weight:700;
    letter-spacing:1px;
    cursor:pointer;
    box-shadow:0 8px 20px rgba(94,26,36,0.4);
    transition:transform 0.2s;
    font-family:'Amiri', serif;
  }
  .wi-openBtn:active{ transform:scale(0.95); }

  .wi-burstWrap{
    position:absolute;
    inset:0;
    display:flex;
    align-items:center;
    justify-content:center;
    pointer-events:none;
    z-index:1;
  }
  .wi-burstPetal{
    position:absolute;
    opacity:0;
    color:var(--gold-light);
  }
  .wi-burstPetal.wi-go{
    animation: wiBurstOut 0.9s ease-out forwards;
  }
  @keyframes wiBurstOut{
    0%{ transform:translate(0,0) scale(0.3) rotate(0deg); opacity:1; }
    100%{ transform:translate(var(--bx), var(--by)) scale(1.1) rotate(var(--br)); opacity:0; }
  }

  /* ===================== MAIN INVITATION ===================== */
  .wi-mainInvite{
    width:100%;
    display:flex;
    justify-content:center;
    padding:20px 10px 20px;
    opacity:0;
    transform:scale(0.92);
    transition:opacity 0.6s ease 0.15s, transform 0.6s ease 0.15s;
  }
  .wi-mainInvite.wi-revealed{
    opacity:1;
    transform:scale(1);
  }

  .wi-card{
    max-width:520px;
    width:100%;
    background:var(--cream);
    border-radius:14px;
    box-shadow:0 20px 60px rgba(94,26,36,0.25);
    overflow:hidden;
    position:relative;
    border:1px solid #e3d6bd;
  }

  .wi-hero{
    position:relative;
    background:linear-gradient(180deg, var(--burgundy) 0%, var(--burgundy-dark) 100%);
    padding:36px 20px 0;
    text-align:center;
    overflow:hidden;
  }

  .wi-hero::before{
    content:"";
    position:absolute;
    inset:8px;
    border:1px solid rgba(212,175,122,0.5);
    pointer-events:none;
  }

  .wi-names{
    font-family:'Aref Ruqaa', serif;
    color:var(--gold-light);
    font-size:2.1rem;
    letter-spacing:1px;
    margin-top:6px;
    text-shadow:0 2px 6px rgba(0,0,0,0.4);
  }

  .wi-subtitle{
    color:#e8d9c0;
    font-size:0.9rem;
    margin-top:4px;
    letter-spacing:1.5px;
  }

  .wi-divider{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    margin:16px 0;
  }
  .wi-divider .wi-line{
    flex:1;
    height:1px;
    background:linear-gradient(90deg, transparent, var(--gold), transparent);
    max-width:80px;
  }
  .wi-divider .wi-icon{
    color:var(--gold);
    font-size:1.2rem;
  }

  .wi-content{
    padding:26px 26px 16px;
    text-align:center;
  }

  .wi-inviteText{
    font-size:1.05rem;
    line-height:2;
    color:var(--burgundy-dark);
  }

  .wi-inviteText strong{
    color:var(--burgundy);
    font-size:1.3rem;
    font-family:'Aref Ruqaa', serif;
    display:block;
    margin-top:6px;
  }

  .wi-verse{
    font-size:0.92rem;
    color:#7a5c3e;
    font-style:italic;
    margin:16px 0;
    line-height:1.9;
    padding:0 6px;
  }

  .wi-details{
    display:flex;
    justify-content:space-around;
    margin:24px 0;
    gap:10px;
  }

  .wi-detailBox{
    background:#fff;
    border:1px solid #e6d7b8;
    border-radius:10px;
    padding:14px 8px;
    flex:1;
    box-shadow:0 4px 12px rgba(94,26,36,0.08);
  }

  .wi-detailBox .wi-icon{
    font-size:1.4rem;
    margin-bottom:6px;
  }

  .wi-detailBox .wi-label{
    font-size:0.78rem;
    color:var(--gold);
    letter-spacing:1px;
  }

  .wi-detailBox .wi-value{
    font-size:1.05rem;
    font-weight:700;
    color:var(--burgundy);
    margin-top:3px;
  }

  .wi-mapBtn{
    display:inline-block;
    margin-top:14px;
    padding:10px 26px;
    background:linear-gradient(135deg,var(--gold-light),var(--gold));
    color:var(--burgundy-dark);
    text-decoration:none;
    border-radius:30px;
    font-weight:700;
    font-size:0.9rem;
    letter-spacing:1px;
    box-shadow:0 4px 14px rgba(176,141,79,0.4);
    transition:transform 0.2s;
  }
  .wi-mapBtn:active{ transform:scale(0.97); }

  .wi-countdown{
    display:flex;
    justify-content:center;
    gap:10px;
    margin:20px 0;
    flex-wrap:wrap;
  }
  .wi-countItem{
    background:var(--burgundy);
    color:#fff;
    border-radius:8px;
    padding:10px 6px;
    min-width:56px;
  }
  .wi-countItem .wi-num{
    font-size:1.3rem;
    font-weight:700;
    display:block;
  }
  .wi-countItem .wi-txt{
    font-size:0.62rem;
    color:var(--gold-light);
    letter-spacing:1px;
  }

  .wi-cakeWrap{
    display:flex;
    justify-content:center;
    margin:10px 0 6px;
  }

  .wi-rsvpSection{
    background:linear-gradient(135deg,#f5ede0,#eee0c8);
    padding:26px 24px;
    text-align:center;
    border-top:1px dashed var(--gold);
  }

  .wi-rsvpTitle{
    font-family:'Aref Ruqaa', serif;
    font-size:1.35rem;
    color:var(--burgundy);
    margin-bottom:14px;
  }

  .wi-rsvpForm input, .wi-rsvpForm select{
    width:100%;
    padding:11px 14px;
    margin-bottom:12px;
    border:1px solid #d8c39a;
    border-radius:8px;
    font-family:'Amiri', serif;
    font-size:0.95rem;
    background:#fff;
    color:var(--burgundy-dark);
  }
  .wi-rsvpForm input:focus, .wi-rsvpForm select:focus{
    outline:none;
    border-color:var(--gold);
  }

  .wi-rsvpBtn{
    width:100%;
    padding:13px;
    background:linear-gradient(135deg,var(--burgundy),var(--burgundy-dark));
    color:var(--gold-light);
    border:none;
    border-radius:8px;
    font-size:1rem;
    font-weight:700;
    cursor:pointer;
    letter-spacing:1px;
    box-shadow:0 4px 14px rgba(94,26,36,0.3);
    transition:transform 0.15s;
  }
  .wi-rsvpBtn:active{ transform:scale(0.98); }

  .wi-thankyou{
    color:var(--burgundy);
    font-size:1.1rem;
    padding:10px;
    font-family:'Aref Ruqaa', serif;
    line-height:1.9;
  }

  .wi-footer{
    text-align:center;
    padding:18px;
    background:var(--burgundy-dark);
  }
  .wi-footer p{
    color:var(--gold-light);
    font-size:0.78rem;
    letter-spacing:1px;
  }

  @media (prefers-color-scheme: dark){
    .wi-root:not([data-theme="light"]){
      --cream:#2a2118;
    }
  }
`;

function FloatingHearts() {
  const hearts = useRef(
    Array.from({ length: 16 }, (_, i) => ({
      id: i,
      symbol: Math.random() > 0.5 ? "♥" : "❤",
      size: 10 + Math.random() * 22,
      left: Math.random() * 100,
      drift: Math.random() * 60 - 30,
      duration: 8 + Math.random() * 10,
      delay: Math.random() * 10,
    }))
  ).current;

  return (
    <div className="wi-heartsBg">
      {hearts.map((h) => (
        <div
          key={h.id}
          className="wi-floatHeart"
          style={{
            fontSize: h.size,
            left: `${h.left}%`,
            "--drift": `${h.drift}px`,
            animationDuration: `${h.duration}s`,
            animationDelay: `${h.delay}s`,
          }}
        >
          {h.symbol}
        </div>
      ))}
    </div>
  );
}

function BurstPetals({ go }) {
  const symbols = ["✦", "❀", "♥", "✿", "❁"];
  const petals = useRef(
    Array.from({ length: 18 }, (_, i) => {
      const angle = (Math.PI * 2 * i) / 18 + Math.random() * 0.3;
      const dist = 140 + Math.random() * 180;
      return {
        id: i,
        symbol: symbols[Math.floor(Math.random() * symbols.length)],
        bx: Math.cos(angle) * dist,
        by: Math.sin(angle) * dist,
        br: Math.random() * 360,
        size: 16 + Math.random() * 16,
      };
    })
  ).current;

  return (
    <div className="wi-burstWrap">
      {petals.map((p) => (
        <span
          key={p.id}
          className={`wi-burstPetal${go ? " wi-go" : ""}`}
          style={{
            "--bx": `${p.bx}px`,
            "--by": `${p.by}px`,
            "--br": `${p.br}deg`,
            fontSize: p.size,
          }}
        >
          {p.symbol}
        </span>
      ))}
    </div>
  );
}

function useCountdown(targetISO) {
  const [timeLeft, setTimeLeft] = useState(null);

  useEffect(() => {
    const target = new Date(targetISO).getTime();

    function tick() {
      const now = Date.now();
      const distance = target - now;
      if (distance < 0) {
        setTimeLeft({ done: true });
        return;
      }
      setTimeLeft({
        done: false,
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((distance % (1000 * 60)) / 1000),
      });
    }

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [targetISO]);

  return timeLeft;
}

export default function WeddingInvite({
  groomName = "أحمد",
  brideName = "سارة",
  weddingDateISO = "2025-11-15T19:00:00",
  weddingDateLabel = "15 نوفمبر",
  weddingYearLabel = "2025",
  weddingTimeLabel = "7:00 م",
  venueName = "قاعة الأمير الملكية",
  venueAddress = "شارع النيل، القاهرة، مصر",
  mapUrl = "https://maps.google.com",
}) {
  const [coverOpening, setCoverOpening] = useState(false);
  const [coverHidden, setCoverHidden] = useState(false);
  const [showCover, setShowCover] = useState(true);
  const [revealed, setRevealed] = useState(false);
  const [burstGo, setBurstGo] = useState(false);

  const [submitted, setSubmitted] = useState(false);
  const [guestName, setGuestName] = useState("");
  const [attending, setAttending] = useState("");
  const [guestCount, setGuestCount] = useState(0);

  const timeLeft = useCountdown(weddingDateISO);

  function handleOpen() {
    // burst
    requestAnimationFrame(() => setBurstGo(true));
    // shrink card
    setCoverOpening(true);
    // reveal main invite
    setTimeout(() => setRevealed(true), 200);
    // fade out cover
    setTimeout(() => setCoverHidden(true), 650);
    // unmount cover
    setTimeout(() => setShowCover(false), 1300);
  }

  function handleSubmit(e) {
    e.preventDefault();
    setSubmitted(true);
  }

  return (
    <div className="wi-root">
      <style>{STYLES}</style>

      {showCover && (
        <div className={`wi-coverScreen${coverHidden ? " wi-hidden" : ""}`}>
          <FloatingHearts />

          <div className={`wi-coverCard${coverOpening ? " wi-opening" : ""}`}>
            <BurstPetals go={burstGo} />

            <div className="wi-heartBadge">
              <svg viewBox="0 0 24 24">
                <path d="M12 21s-6.7-4.35-9.3-8.1C.9 10.1 1.4 6.6 4.2 5c2.2-1.25 4.7-.6 6.1 1.3.6.8 1 .8 1.4 0C13.1 4.4 15.6 3.75 17.8 5c2.8 1.6 3.3 5.1 1.5 7.9C18.7 16.65 12 21 12 21z" />
              </svg>
            </div>

            <div className="wi-coverNames">
              {groomName}
              <br />
              <span className="wi-coverAmp">&amp;</span>
              <br />
              {brideName}
            </div>

            <div className="wi-coverDivider">
              <span className="wi-line"></span>
              <span className="wi-dot">✦</span>
              <span className="wi-line"></span>
            </div>

            <div className="wi-coverDate">
              {weddingDateLabel} {weddingYearLabel}
            </div>
            <div className="wi-coverInviteTxt">بكل الحب يتشرفون بدعوتكم</div>

            <button className="wi-openBtn" onClick={handleOpen}>
              فتح الدعوة
            </button>
          </div>
        </div>
      )}

      <div className={`wi-mainInvite${revealed ? " wi-revealed" : ""}`}>
        <div className="wi-card">
          <div className="wi-hero">
            <div className="wi-subtitle">بِسْمِ اللهِ الرَّحْمَنِ الرَّحِيمِ</div>
            <div className="wi-divider" style={{ marginTop: 14 }}>
              <span className="wi-line"></span>
              <span className="wi-icon">💍</span>
              <span className="wi-line"></span>
            </div>
            <div className="wi-names">
              {groomName} &amp; {brideName}
            </div>
            <div className="wi-subtitle">يتشرفان بدعوتكم لحضور حفل زفافهما</div>
            <div style={{ height: 22 }}></div>
          </div>

          <div className="wi-content">
            <p className="wi-inviteText">
              يسعدنا دعوتكم لمشاركتنا أجمل لحظات حياتنا
              <strong>
                حفل زفاف {groomName} و{brideName}
              </strong>
            </p>

            <p className="wi-verse">
              "وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا
              لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً"
            </p>

            <div className="wi-details">
              <div className="wi-detailBox">
                <div className="wi-icon">📅</div>
                <div className="wi-label">التاريخ</div>
                <div className="wi-value">{weddingDateLabel}</div>
              </div>
              <div className="wi-detailBox">
                <div className="wi-icon">🕖</div>
                <div className="wi-label">الوقت</div>
                <div className="wi-value">{weddingTimeLabel}</div>
              </div>
              <div className="wi-detailBox">
                <div className="wi-icon">📆</div>
                <div className="wi-label">السنة</div>
                <div className="wi-value">{weddingYearLabel}</div>
              </div>
            </div>

            <div className="wi-countdown">
              {timeLeft?.done ? (
                <div
                  style={{
                    color: "var(--burgundy)",
                    fontFamily: "'Aref Ruqaa', serif",
                    fontSize: "1.2rem",
                  }}
                >
                  اليوم المنتظر قد حان 🎉
                </div>
              ) : (
                <>
                  <div className="wi-countItem">
                    <span className="wi-num">{timeLeft?.days ?? "--"}</span>
                    <span className="wi-txt">يوم</span>
                  </div>
                  <div className="wi-countItem">
                    <span className="wi-num">{timeLeft?.hours ?? "--"}</span>
                    <span className="wi-txt">ساعة</span>
                  </div>
                  <div className="wi-countItem">
                    <span className="wi-num">{timeLeft?.minutes ?? "--"}</span>
                    <span className="wi-txt">دقيقة</span>
                  </div>
                  <div className="wi-countItem">
                    <span className="wi-num">{timeLeft?.seconds ?? "--"}</span>
                    <span className="wi-txt">ثانية</span>
                  </div>
                </>
              )}
            </div>

            <div className="wi-divider">
              <span className="wi-line"></span>
              <span className="wi-icon">✦</span>
              <span className="wi-line"></span>
            </div>

            <div className="wi-venueName" style={{ fontFamily: "'Aref Ruqaa', serif", fontSize: "1.4rem", color: "var(--burgundy)", marginTop: 6 }}>
              {venueName}
            </div>
            <div style={{ color: "#7a5c3e", fontSize: "0.9rem", marginTop: 4 }}>
              {venueAddress}
            </div>
            <a className="wi-mapBtn" href={mapUrl} target="_blank" rel="noopener noreferrer">
              📍 عرض الموقع على الخريطة
            </a>

            <div className="wi-cakeWrap">
              <span style={{ fontSize: "3rem" }}>🎂</span>
            </div>
          </div>

          <div className="wi-rsvpSection">
            <div className="wi-rsvpTitle">يرجى تأكيد الحضور</div>

            {!submitted ? (
              <form className="wi-rsvpForm" onSubmit={handleSubmit}>
                <input
                  type="text"
                  placeholder="الاسم الكامل"
                  required
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                />
                <select
                  required
                  value={attending}
                  onChange={(e) => setAttending(e.target.value)}
                >
                  <option value="" disabled>
                    هل ستحضر؟
                  </option>
                  <option value="yes">نعم، سأحضر بكل سرور</option>
                  <option value="no">عذرًا، لن أتمكن من الحضور</option>
                </select>
                <input
                  type="number"
                  placeholder="عدد الأشخاص المرافقين"
                  min="0"
                  max="10"
                  value={guestCount}
                  onChange={(e) => setGuestCount(e.target.value)}
                />
                <button type="submit" className="wi-rsvpBtn">
                  تأكيد الحضور
                </button>
              </form>
            ) : (
              <div className="wi-thankyou">
                شكرًا لتأكيدكم 💌
                <br />
                نتشرف بحضوركم معنا
              </div>
            )}
          </div>

          <footer className="wi-footer">
            <p>بانتظار شرفكم ✦ {weddingYearLabel}</p>
          </footer>
        </div>
      </div>
    </div>
  );
}




// import React, { useEffect, useRef, useState, useCallback } from "react";
// import * as XLSX from "xlsx";

// /* ---------------------------------------------------------
//    Yomna & Ahmed — Wedding Invitation
//    Design tokens
//    ivory        #FBF7F1
//    deep ivory   #F3EBE1  (section alternation)
//    champagne    #B9925A
//    deep gold    #8C6A34
//    ink          #2E2A24
//    ink soft     #6B6255
//    rose whisper #E7D6CC (hairline / divider only)
// --------------------------------------------------------- */

// const WEDDING_DATE = new Date("2026-10-15T15:00:00");

// function useReveal() {
//   const ref = useRef(null);
//   const [visible, setVisible] = useState(false);
//   useEffect(() => {
//     const el = ref.current;
//     if (!el) return;
//     const io = new IntersectionObserver(
//       ([entry]) => {
//         if (entry.isIntersecting) {
//           setVisible(true);
//           io.unobserve(el);
//         }
//       },
//       { threshold: 0.18 }
//     );
//     io.observe(el);
//     return () => io.disconnect();
//   }, []);
//   return [ref, visible];
// }

// function Reveal({ as: Tag = "div", className = "", delay = 0, children, ...rest }) {
//   const [ref, visible] = useReveal();
//   return (
//     <Tag
//       ref={ref}
//       className={className}
//       style={{
//         opacity: visible ? 1 : 0,
//         transform: visible ? "translateY(0px)" : "translateY(22px)",
//         transition: `opacity 1.1s cubic-bezier(.19,1,.22,1) ${delay}s, transform 1.1s cubic-bezier(.19,1,.22,1) ${delay}s`,
//       }}
//       {...rest}
//     >
//       {children}
//     </Tag>
//   );
// }

// function Ornament({ className = "" }) {
//   return (
//     <svg
//       viewBox="0 0 240 40"
//       className={className}
//       fill="none"
//       xmlns="http://www.w3.org/2000/svg"
//     >
//       <path
//         d="M0 20 H90"
//         stroke="currentColor"
//         strokeWidth="0.75"
//         opacity="0.55"
//       />
//       <path
//         d="M150 20 H240"
//         stroke="currentColor"
//         strokeWidth="0.75"
//         opacity="0.55"
//       />
//       <g transform="translate(120,20)">
//         <path
//           d="M0 -12 C6 -6 6 6 0 12 C-6 6 -6 -6 0 -12 Z"
//           fill="currentColor"
//           opacity="0.85"
//         />
//         <circle cx="-18" cy="0" r="2.2" fill="currentColor" opacity="0.6" />
//         <circle cx="18" cy="0" r="2.2" fill="currentColor" opacity="0.6" />
//         <circle cx="-28" cy="0" r="1.3" fill="currentColor" opacity="0.4" />
//         <circle cx="28" cy="0" r="1.3" fill="currentColor" opacity="0.4" />
//       </g>
//     </svg>
//   );
// }

// function CornerFlourish({ className = "" }) {
//   return (
//     <svg
//       viewBox="0 0 120 120"
//       className={className}
//       fill="none"
//       xmlns="http://www.w3.org/2000/svg"
//     >
//       <path
//         d="M4 4 C 4 40, 20 60, 60 60"
//         stroke="currentColor"
//         strokeWidth="0.75"
//         opacity="0.5"
//       />
//       <path
//         d="M4 4 C 40 4, 60 20, 60 60"
//         stroke="currentColor"
//         strokeWidth="0.75"
//         opacity="0.5"
//       />
//       <circle cx="4" cy="4" r="2.5" fill="currentColor" opacity="0.7" />
//     </svg>
//   );
// }

// function useCountdown(target) {
//   const [t, setT] = useState(() => Math.max(0, target - Date.now()));
//   useEffect(() => {
//     const id = setInterval(() => {
//       setT(Math.max(0, target - Date.now()));
//     }, 1000);
//     return () => clearInterval(id);
//   }, [target]);
//   const s = Math.floor(t / 1000);
//   return {
//     days: Math.floor(s / 86400),
//     hours: Math.floor((s % 86400) / 3600),
//     minutes: Math.floor((s % 3600) / 60),
//     seconds: s % 60,
//   };
// }

// const NAV_ITEMS = [
//   { id: "home", label: "Home" },
//   { id: "details", label: "Details" },
//   { id: "gallery", label: "Gallery" },
//   { id: "wishes", label: "Wishes" },
// ];

// const RELATION_OPTIONS = [
//   "Bride's Family",
//   "Groom's Family",
//   "Bride's Friend",
//   "Groom's Friend",
//   "Colleague",
//   "Other",
// ];

// function useMousePosition() {
//   const [pos, setPos] = useState({ x: 0.5, y: 0.5 });
//   useEffect(() => {
//     const onMove = (e) => {
//       setPos({ x: e.clientX / window.innerWidth, y: e.clientY / window.innerHeight });
//     };
//     window.addEventListener("mousemove", onMove);
//     return () => window.removeEventListener("mousemove", onMove);
//   }, []);
//   return pos;
// }

// function useScrollY() {
//   const [y, setY] = useState(0);
//   useEffect(() => {
//     const onScroll = () => setY(window.scrollY);
//     window.addEventListener("scroll", onScroll, { passive: true });
//     return () => window.removeEventListener("scroll", onScroll);
//   }, []);
//   return y;
// }

// export default function WeddingInvitation() {
//   const [opened, setOpened] = useState(false);
//   const [menuOpen, setMenuOpen] = useState(false);
//   const [scrolled, setScrolled] = useState(false);
//   const cd = useCountdown(WEDDING_DATE.getTime());

//   const [wishForm, setWishForm] = useState({ name: "", message: "", relation: RELATION_OPTIONS[0] });
//   const [wishes, setWishes] = useState([]);

//   const [loading, setLoading] = useState(true);
//   const [loadingExit, setLoadingExit] = useState(false);

//   const [audioPlaying, setAudioPlaying] = useState(false);
//   const audioRef = useRef(null);

//   const mouse = useMousePosition();
//   const scrollY = useScrollY();

//   useEffect(() => {
//     const exitTimer = setTimeout(() => setLoadingExit(true), 2400);
//     const removeTimer = setTimeout(() => setLoading(false), 3100);
//     return () => {
//       clearTimeout(exitTimer);
//       clearTimeout(removeTimer);
//     };
//   }, []);

//   const toggleAudio = useCallback(() => {
//     const el = audioRef.current;
//     if (!el) return;
//     if (audioPlaying) {
//       el.pause();
//       setAudioPlaying(false);
//     } else {
//       el.play().catch(() => {});
//       setAudioPlaying(true);
//     }
//   }, [audioPlaying]);

//   useEffect(() => {
//     const onScroll = () => setScrolled(window.scrollY > 40);
//     window.addEventListener("scroll", onScroll);
//     return () => window.removeEventListener("scroll", onScroll);
//   }, []);

//   const scrollTo = useCallback((id) => {
//     setMenuOpen(false);
//     const el = document.getElementById(id);
//     if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
//   }, []);

//   const handleWishSubmit = (e) => {
//     e.preventDefault();
//     if (!wishForm.name.trim() || !wishForm.message.trim()) return;
//     setWishes((prev) => [
//       {
//         name: wishForm.name.trim(),
//         message: wishForm.message.trim(),
//         relation: wishForm.relation,
//         date: new Date(),
//       },
//       ...prev,
//     ]);
//     setWishForm({ name: "", message: "", relation: RELATION_OPTIONS[0] });
//   };

//   const exportWishesToExcel = () => {
//     const rows = wishes.map((w) => ({
//       Name: w.name,
//       Relation: w.relation,
//       Message: w.message,
//       Date: w.date.toLocaleString(),
//     }));
//     const ws = XLSX.utils.json_to_sheet(
//       rows.length ? rows : [{ Name: "", Relation: "", Message: "", Date: "" }]
//     );
//     ws["!cols"] = [{ wch: 24 }, { wch: 18 }, { wch: 60 }, { wch: 20 }];
//     const wb = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(wb, ws, "Wishes");
//     XLSX.writeFile(wb, "yomna-ahmed-wishes.xlsx");
//   };

//   return (
//     <div
//       className="wedding-root"
//       style={{
//         fontFamily: "'Jost', 'Helvetica Neue', sans-serif",
//         background: "#FBF7F1",
//         color: "#2E2A24",
//         minHeight: "100vh",
//         position: "relative",
//         overflowX: "hidden",
//       }}
//     >
//       <style>{`
//         @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,400&family=Jost:wght@300;400;500&display=swap');
//         .wedding-root * { box-sizing: border-box; }
//         .serif { font-family: 'Cormorant Garamond', serif; }
//         .tracked { letter-spacing: 0.14em; }
//         @media (prefers-reduced-motion: reduce) {
//           .wedding-root * { animation: none !important; transition: none !important; }
//         }
//         .nav-link { position: relative; }
//         .nav-link::after {
//           content: "";
//           position: absolute;
//           left: 0; right: 0; bottom: -6px;
//           height: 1px;
//           background: #8C6A34;
//           transform: scaleX(0);
//           transform-origin: left;
//           transition: transform 0.5s cubic-bezier(.19,1,.22,1);
//         }
//         .nav-link:hover::after { transform: scaleX(1); }
//         @keyframes floatSlow {
//           0%, 100% { transform: translateY(0px) rotate(0deg); }
//           50% { transform: translateY(-14px) rotate(3deg); }
//         }
//         @keyframes heroReveal {
//           0% { opacity: 0; transform: translateY(18px); letter-spacing: 0.02em; }
//           100% { opacity: 1; transform: translateY(0); letter-spacing: 0.01em; }
//         }
//         .hero-word { display: inline-block; animation: heroReveal 1.4s cubic-bezier(.19,1,.22,1) both; }
//         .gallery-item { transition: transform 1.1s cubic-bezier(.19,1,.22,1), filter 0.6s ease; }
//         .gallery-item:hover { transform: scale(1.015); filter: saturate(1.05); }
//         input, textarea, select { font-family: 'Jost', sans-serif; }
//         input:focus, textarea:focus, select:focus {
//           outline: none;
//           border-color: #8C6A34 !important;
//         }
//         ::selection { background: #E7D6CC; }
//         @keyframes loaderFade {
//           0% { opacity: 0; transform: translateY(10px); }
//           100% { opacity: 1; transform: translateY(0); }
//         }
//         @keyframes loaderLine {
//           0% { transform: scaleX(0); }
//           100% { transform: scaleX(1); }
//         }
//         .loader-name { animation: loaderFade 1.1s cubic-bezier(.19,1,.22,1) both; }
//         .loader-rule { animation: loaderLine 1.6s cubic-bezier(.19,1,.22,1) 0.3s both; transform-origin: center; }
//         .sound-toggle { transition: all 0.4s cubic-bezier(.19,1,.22,1); }
//         .sound-toggle:hover { transform: scale(1.08); }
//         .sound-bar { transition: height 0.3s ease; }
//       `}</style>

//       {/* ---------------- LOADING SCREEN ---------------- */}
//       {loading && (
//         <div
//           aria-hidden
//           style={{
//             position: "fixed",
//             inset: 0,
//             zIndex: 100,
//             background: "#FBF7F1",
//             display: "flex",
//             flexDirection: "column",
//             alignItems: "center",
//             justifyContent: "center",
//             opacity: loadingExit ? 0 : 1,
//             transition: "opacity 0.7s cubic-bezier(.19,1,.22,1)",
//             pointerEvents: loadingExit ? "none" : "auto",
//           }}
//         >
//           <p
//             className="tracked loader-name"
//             style={{
//               fontSize: 11,
//               color: "#B9925A",
//               textTransform: "uppercase",
//               marginBottom: 22,
//             }}
//           >
//             The Wedding Of
//           </p>
//           <h1
//             className="serif loader-name"
//             style={{
//               fontSize: "clamp(34px, 6vw, 60px)",
//               fontWeight: 400,
//               color: "#2E2A24",
//               margin: 0,
//               animationDelay: "0.15s",
//             }}
//           >
//             Yomna <span style={{ color: "#B9925A", fontStyle: "italic" }}>&amp;</span> Ahmed
//           </h1>
//           <div
//             className="loader-rule"
//             style={{
//               width: 90,
//               height: 1,
//               background: "#B9925A",
//               marginTop: 28,
//             }}
//           />
//         </div>
//       )}

//       {/* ---------------- BACKGROUND AMBIENT AUDIO ---------------- */}
//       <audio ref={audioRef} loop preload="none">
//         <source
//           src="https://cdn.pixabay.com/download/audio/2022/03/10/audio_c8f7d69f8a.mp3"
//           type="audio/mpeg"
//         />
//       </audio>

//       <button
//         onClick={toggleAudio}
//         className="sound-toggle"
//         aria-label={audioPlaying ? "Mute music" : "Play music"}
//         style={{
//           position: "fixed",
//           bottom: 24,
//           right: 24,
//           zIndex: 50,
//           width: 48,
//           height: 48,
//           borderRadius: "50%",
//           background: "rgba(251,247,241,0.9)",
//           border: "1px solid #B9925A",
//           backdropFilter: "blur(6px)",
//           cursor: "pointer",
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "center",
//           gap: 2,
//         }}
//       >
//         {audioPlaying ? (
//           <>
//             <span className="sound-bar" style={{ width: 2.5, height: 8, background: "#8C6A34", borderRadius: 2 }} />
//             <span className="sound-bar" style={{ width: 2.5, height: 14, background: "#8C6A34", borderRadius: 2 }} />
//             <span className="sound-bar" style={{ width: 2.5, height: 6, background: "#8C6A34", borderRadius: 2 }} />
//             <span className="sound-bar" style={{ width: 2.5, height: 11, background: "#8C6A34", borderRadius: 2 }} />
//           </>
//         ) : (
//           <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
//             <path d="M4 9V15H8L13 20V4L8 9H4Z" fill="#8C6A34" />
//             <path d="M17 8L21 16M21 8L17 16" stroke="#8C6A34" strokeWidth="1.5" strokeLinecap="round" />
//           </svg>
//         )}
//       </button>

//       {/* ---------------- NAV ---------------- */}
//       <nav
//         style={{
//           position: "fixed",
//           top: 0,
//           left: 0,
//           right: 0,
//           zIndex: 40,
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "space-between",
//           padding: scrolled ? "16px 6vw" : "28px 6vw",
//           background: scrolled ? "rgba(251,247,241,0.92)" : "transparent",
//           backdropFilter: scrolled ? "blur(8px)" : "none",
//           borderBottom: scrolled ? "1px solid #E7D6CC" : "1px solid transparent",
//           transition: "all 0.5s cubic-bezier(.19,1,.22,1)",
//         }}
//       >
//         <button
//           onClick={() => scrollTo("home")}
//           className="serif"
//           style={{
//             fontSize: 20,
//             letterSpacing: "0.08em",
//             background: "none",
//             border: "none",
//             cursor: "pointer",
//             color: "#2E2A24",
//           }}
//         >
//           Y &amp; A
//         </button>

//         <div style={{ display: "flex", gap: 40 }} className="nav-desktop">
//           {NAV_ITEMS.map((item) => (
//             <button
//               key={item.id}
//               onClick={() => scrollTo(item.id)}
//               className="nav-link tracked"
//               style={{
//                 background: "none",
//                 border: "none",
//                 cursor: "pointer",
//                 fontSize: 12,
//                 textTransform: "uppercase",
//                 color: "#6B6255",
//               }}
//             >
//               {item.label}
//             </button>
//           ))}
//         </div>

//         <button
//           onClick={() => setMenuOpen((v) => !v)}
//           className="nav-mobile-btn"
//           style={{
//             display: "none",
//             background: "none",
//             border: "1px solid #B9925A",
//             width: 38,
//             height: 38,
//             borderRadius: "50%",
//             cursor: "pointer",
//             alignItems: "center",
//             justifyContent: "center",
//           }}
//           aria-label="Menu"
//         >
//           <div style={{ width: 14 }}>
//             <div style={{ height: 1, background: "#2E2A24", marginBottom: 4 }} />
//             <div style={{ height: 1, background: "#2E2A24", marginBottom: 4 }} />
//             <div style={{ height: 1, background: "#2E2A24" }} />
//           </div>
//         </button>

//         <style>{`
//           @media (max-width: 780px) {
//             .nav-desktop { display: none !important; }
//             .nav-mobile-btn { display: flex !important; }
//           }
//         `}</style>
//       </nav>

//       {menuOpen && (
//         <div
//           style={{
//             position: "fixed",
//             inset: 0,
//             zIndex: 39,
//             background: "#FBF7F1",
//             display: "flex",
//             flexDirection: "column",
//             alignItems: "center",
//             justifyContent: "center",
//             gap: 28,
//           }}
//         >
//           {NAV_ITEMS.map((item) => (
//             <button
//               key={item.id}
//               onClick={() => scrollTo(item.id)}
//               className="serif"
//               style={{
//                 background: "none",
//                 border: "none",
//                 fontSize: 28,
//                 cursor: "pointer",
//                 color: "#2E2A24",
//               }}
//             >
//               {item.label}
//             </button>
//           ))}
//           <button
//             onClick={() => setMenuOpen(false)}
//             className="tracked"
//             style={{
//               marginTop: 20,
//               background: "none",
//               border: "none",
//               fontSize: 12,
//               color: "#8C6A34",
//               cursor: "pointer",
//               textTransform: "uppercase",
//             }}
//           >
//             Close
//           </button>
//         </div>
//       )}

//       {/* ---------------- HERO ---------------- */}
//       <section
//         id="home"
//         style={{
//           minHeight: "100vh",
//           display: "flex",
//           flexDirection: "column",
//           alignItems: "center",
//           justifyContent: "center",
//           textAlign: "center",
//           position: "relative",
//           padding: "120px 6vw 80px",
//           overflow: "hidden",
//         }}
//       >
//         {/* parallax background layer */}
//         <div
//           aria-hidden
//           style={{
//             position: "absolute",
//             inset: "-10%",
//             background:
//               "radial-gradient(ellipse at 50% 0%, #F3EBE1 0%, #FBF7F1 62%)",
//             transform: `translate(${(mouse.x - 0.5) * -16}px, ${
//               (mouse.y - 0.5) * -16 - scrollY * 0.12
//             }px)`,
//             transition: "transform 0.2s ease-out",
//             zIndex: 0,
//           }}
//         />

//         {/* floating ornamental dots (parallax layers) */}
//         <div
//           aria-hidden
//           style={{
//             position: "absolute",
//             top: "14%",
//             left: "10%",
//             width: 6,
//             height: 6,
//             borderRadius: "50%",
//             background: "#D9B8B0",
//             animation: "floatSlow 7s ease-in-out infinite",
//             transform: `translate(${(mouse.x - 0.5) * 34}px, ${
//               (mouse.y - 0.5) * 34 - scrollY * 0.25
//             }px)`,
//             transition: "transform 0.15s ease-out",
//             zIndex: 1,
//           }}
//         />
//         <div
//           aria-hidden
//           style={{
//             position: "absolute",
//             top: "22%",
//             right: "12%",
//             width: 4,
//             height: 4,
//             borderRadius: "50%",
//             background: "#B9925A",
//             animation: "floatSlow 9s ease-in-out infinite 1s",
//             transform: `translate(${(mouse.x - 0.5) * -46}px, ${
//               (mouse.y - 0.5) * -46 - scrollY * 0.35
//             }px)`,
//             transition: "transform 0.15s ease-out",
//             zIndex: 1,
//           }}
//         />
//         <div
//           aria-hidden
//           style={{
//             position: "absolute",
//             bottom: "18%",
//             left: "16%",
//             width: 5,
//             height: 5,
//             borderRadius: "50%",
//             background: "#B9925A",
//             animation: "floatSlow 8s ease-in-out infinite 0.5s",
//             transform: `translate(${(mouse.x - 0.5) * 24}px, ${
//               (mouse.y - 0.5) * 24 - scrollY * 0.18
//             }px)`,
//             transition: "transform 0.15s ease-out",
//             zIndex: 1,
//           }}
//         />

//         <p
//           className="tracked hero-word"
//           style={{
//             fontSize: 12,
//             textTransform: "uppercase",
//             color: "#8C6A34",
//             marginBottom: 28,
//             animationDelay: "0.1s",
//             position: "relative",
//             zIndex: 2,
//           }}
//         >
//           Together with their families
//         </p>

//         <h1
//           className="serif hero-word"
//           style={{
//             fontSize: "clamp(52px, 11vw, 132px)",
//             fontWeight: 400,
//             lineHeight: 1.02,
//             margin: 0,
//             color: "#2E2A24",
//             animationDelay: "0.3s",
//             position: "relative",
//             zIndex: 2,
//           }}
//         >
//           Yomna <span style={{ color: "#B9925A", fontStyle: "italic" }}>&amp;</span> Ahmed
//         </h1>

//         <Ornament
//           className="hero-word"
//           style={{ width: 160, height: 28, color: "#B9925A", margin: "30px auto", animationDelay: "0.6s", position: "relative", zIndex: 2 }}
//         />

//         <p
//           className="serif hero-word"
//           style={{
//             fontSize: "clamp(17px, 2vw, 22px)",
//             fontStyle: "italic",
//             color: "#6B6255",
//             maxWidth: 460,
//             lineHeight: 1.6,
//             marginBottom: 36,
//             animationDelay: "0.75s",
//             position: "relative",
//             zIndex: 2,
//           }}
//         >
//           they invite you to celebrate their wedding
//         </p>

//         <p
//           className="tracked hero-word"
//           style={{
//             fontSize: 14,
//             color: "#2E2A24",
//             marginBottom: 48,
//             animationDelay: "0.9s",
//             position: "relative",
//             zIndex: 2,
//           }}
//         >
//           15 &middot; October &middot; 2026
//         </p>

//         <button
//           onClick={() => {
//             setOpened(true);
//             scrollTo("details");
//           }}
//           className="hero-word tracked"
//           style={{
//             background: "transparent",
//             border: "1px solid #8C6A34",
//             color: "#8C6A34",
//             padding: "16px 44px",
//             fontSize: 12,
//             textTransform: "uppercase",
//             cursor: "pointer",
//             transition: "all 0.5s cubic-bezier(.19,1,.22,1)",
//             animationDelay: "1.1s",
//             position: "relative",
//             zIndex: 2,
//           }}
//           onMouseEnter={(e) => {
//             e.currentTarget.style.background = "#8C6A34";
//             e.currentTarget.style.color = "#FBF7F1";
//           }}
//           onMouseLeave={(e) => {
//             e.currentTarget.style.background = "transparent";
//             e.currentTarget.style.color = "#8C6A34";
//           }}
//         >
//           Open Invitation
//         </button>
//       </section>

//       {/* ---------------- COUPLE ---------------- */}
//       <section
//         style={{
//           padding: "140px 6vw",
//           maxWidth: 1100,
//           margin: "0 auto",
//           display: "grid",
//           gridTemplateColumns: "0.9fr 1.1fr",
//           gap: "6vw",
//           alignItems: "center",
//         }}
//       >
//         <Reveal
//           style={{
//             aspectRatio: "3/4",
//             background:
//               "linear-gradient(155deg, #E7D6CC 0%, #F3EBE1 55%, #FBF7F1 100%)",
//             position: "relative",
//             overflow: "hidden",
//           }}
//         >
//           <CornerFlourish
//             style={{
//               position: "absolute",
//               top: 18,
//               left: 18,
//               width: 60,
//               height: 60,
//               color: "#B9925A",
//             }}
//           />
//           <div
//             style={{
//               position: "absolute",
//               inset: 0,
//               display: "flex",
//               alignItems: "center",
//               justifyContent: "center",
//             }}
//           >
//             <span
//               className="serif"
//               style={{ fontSize: 15, color: "#8C6A34", fontStyle: "italic" }}
//             >
//               a portrait, chosen with love
//             </span>
//           </div>
//         </Reveal>

//         <Reveal delay={0.15}>
//           <p className="tracked" style={{ fontSize: 12, color: "#B9925A", marginBottom: 18, textTransform: "uppercase" }}>
//             The Couple
//           </p>
//           <h2 className="serif" style={{ fontSize: "clamp(34px, 4vw, 54px)", fontWeight: 400, margin: "0 0 26px", lineHeight: 1.1 }}>
//             Yomna &amp; Ahmed
//           </h2>
//           <p style={{ fontSize: 17, lineHeight: 1.9, color: "#6B6255", maxWidth: 480, fontWeight: 300 }}>
//             What began as quiet conversations grew, slowly and surely, into a
//             lifetime promise. Between long walks, shared laughter, and two
//             families brought closer together, Yomna and Ahmed found in one
//             another a steady kind of love — the kind that doesn't rush, and
//             doesn't need to. Now, they begin their next chapter, and they
//             would be honored to have you beside them as it opens.
//           </p>
//         </Reveal>
//       </section>

//       {/* ---------------- DETAILS ---------------- */}
//       <section
//         id="details"
//         style={{
//           background: "#F3EBE1",
//           padding: "140px 6vw",
//           textAlign: "center",
//         }}
//       >
//         <Reveal>
//           <p className="tracked" style={{ fontSize: 12, color: "#8C6A34", textTransform: "uppercase", marginBottom: 18 }}>
//             Save the Date
//           </p>
//           <h2 className="serif" style={{ fontSize: "clamp(32px, 4vw, 50px)", fontWeight: 400, margin: "0 0 50px" }}>
//             The Wedding
//           </h2>
//         </Reveal>

//         <div
//           style={{
//             display: "grid",
//             gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
//             gap: 48,
//             maxWidth: 900,
//             margin: "0 auto 56px",
//           }}
//         >
//           {[
//             { label: "Date", value: "October 15, 2026" },
//             { label: "Time", value: "3:00 PM" },
//             { label: "Venue", value: "The Garden Pavilion" },
//             { label: "Location", value: "Alexandria, Egypt" },
//           ].map((d, i) => (
//             <Reveal key={d.label} delay={i * 0.1}>
//               <p className="tracked" style={{ fontSize: 11, color: "#B9925A", textTransform: "uppercase", marginBottom: 10 }}>
//                 {d.label}
//               </p>
//               <p className="serif" style={{ fontSize: 22, color: "#2E2A24" }}>
//                 {d.value}
//               </p>
//             </Reveal>
//           ))}
//         </div>

//         <Reveal delay={0.4}>
//           <button
//             className="tracked"
//             style={{
//               background: "transparent",
//               border: "1px solid #8C6A34",
//               color: "#8C6A34",
//               padding: "15px 40px",
//               fontSize: 12,
//               textTransform: "uppercase",
//               cursor: "pointer",
//               transition: "all 0.5s cubic-bezier(.19,1,.22,1)",
//             }}
//             onMouseEnter={(e) => {
//               e.currentTarget.style.background = "#8C6A34";
//               e.currentTarget.style.color = "#F3EBE1";
//             }}
//             onMouseLeave={(e) => {
//               e.currentTarget.style.background = "transparent";
//               e.currentTarget.style.color = "#8C6A34";
//             }}
//           >
//             View Location
//           </button>
//         </Reveal>

//         {/* countdown */}
//         <Reveal delay={0.5} style={{ marginTop: 88 }}>
//           <p className="serif" style={{ fontSize: 20, fontStyle: "italic", color: "#6B6255", marginBottom: 36 }}>
//             We can't wait to celebrate with you
//           </p>
//           <div style={{ display: "flex", justifyContent: "center", gap: "clamp(20px, 4vw, 56px)", flexWrap: "wrap" }}>
//             {[
//               { label: "Days", value: cd.days },
//               { label: "Hours", value: cd.hours },
//               { label: "Minutes", value: cd.minutes },
//               { label: "Seconds", value: cd.seconds },
//             ].map((u) => (
//               <div key={u.label} style={{ textAlign: "center", minWidth: 64 }}>
//                 <div className="serif" style={{ fontSize: "clamp(32px, 5vw, 48px)", color: "#2E2A24", fontVariantNumeric: "tabular-nums" }}>
//                   {String(u.value).padStart(2, "0")}
//                 </div>
//                 <div className="tracked" style={{ fontSize: 10, color: "#8C6A34", textTransform: "uppercase", marginTop: 6 }}>
//                   {u.label}
//                 </div>
//               </div>
//             ))}
//           </div>
//         </Reveal>
//       </section>

//       {/* ---------------- GALLERY ---------------- */}
//       <section id="gallery" style={{ background: "#F3EBE1", padding: "140px 6vw" }}>
//         <Reveal style={{ textAlign: "center", marginBottom: 72 }}>
//           <p className="tracked" style={{ fontSize: 12, color: "#8C6A34", textTransform: "uppercase", marginBottom: 18 }}>
//             Moments
//           </p>
//           <h2 className="serif" style={{ fontSize: "clamp(32px, 4vw, 50px)", fontWeight: 400, margin: 0 }}>
//             Gallery
//           </h2>
//         </Reveal>

//         <div
//           style={{
//             maxWidth: 1200,
//             margin: "0 auto",
//             display: "grid",
//             gridTemplateColumns: "repeat(6, 1fr)",
//             gridAutoRows: "140px",
//             gap: 14,
//           }}
//           className="gallery-grid"
//         >
//           {[
//             { span: "span 3 / span 3", row: "span 3" },
//             { span: "span 3 / span 3", row: "span 2" },
//             { span: "span 3 / span 3", row: "span 2" },
//             { span: "span 3 / span 3", row: "span 3" },
//             { span: "span 2 / span 2", row: "span 2" },
//             { span: "span 2 / span 2", row: "span 2" },
//             { span: "span 2 / span 2", row: "span 2" },
//           ].map((g, i) => (
//             <Reveal
//               key={i}
//               delay={(i % 4) * 0.08}
//               className="gallery-item"
//               style={{
//                 gridColumn: g.span,
//                 gridRow: g.row,
//                 background: `linear-gradient(${135 + i * 15}deg, #E7D6CC, #F3EBE1)`,
//                 position: "relative",
//                 overflow: "hidden",
//               }}
//             >
//               <div
//                 style={{
//                   position: "absolute",
//                   inset: 0,
//                   display: "flex",
//                   alignItems: "center",
//                   justifyContent: "center",
//                 }}
//               >
//                 <span className="serif" style={{ fontSize: 13, color: "#8C6A34", fontStyle: "italic", opacity: 0.8 }}>
//                   photograph {i + 1}
//                 </span>
//               </div>
//             </Reveal>
//           ))}
//         </div>

//         <style>{`
//           @media (max-width: 700px) {
//             .gallery-grid { grid-template-columns: repeat(2, 1fr) !important; grid-auto-rows: 160px !important; }
//             .gallery-grid > * { grid-column: span 2 !important; grid-row: span 2 !important; }
//           }
//         `}</style>
//       </section>

//       {/* ---------------- WISHES ---------------- */}
//       <section id="wishes" style={{ background: "#F3EBE1", padding: "140px 6vw" }}>
//         <div style={{ maxWidth: 640, margin: "0 auto" }}>
//           <Reveal style={{ textAlign: "center", marginBottom: 56 }}>
//             <p className="tracked" style={{ fontSize: 12, color: "#8C6A34", textTransform: "uppercase", marginBottom: 18 }}>
//               Leave a Note
//             </p>
//             <h2 className="serif" style={{ fontSize: "clamp(32px, 4vw, 50px)", fontWeight: 400, margin: "0 0 18px" }}>
//               Send Your Wishes
//             </h2>
//             <p style={{ fontSize: 16, color: "#6B6255", fontWeight: 300 }}>
//               A few words for Yomna &amp; Ahmed, to keep forever.
//             </p>
//           </Reveal>

//           <Reveal>
//             <form onSubmit={handleWishSubmit} style={{ display: "flex", flexDirection: "column", gap: 26, marginBottom: 72 }}>
//               <div>
//                 <label className="tracked" style={{ fontSize: 11, color: "#8C6A34", textTransform: "uppercase" }}>
//                   Your Name
//                 </label>
//                 <input
//                   required
//                   value={wishForm.name}
//                   onChange={(e) => setWishForm({ ...wishForm, name: e.target.value })}
//                   style={{
//                     width: "100%",
//                     marginTop: 10,
//                     padding: "12px 2px",
//                     background: "transparent",
//                     border: "none",
//                     borderBottom: "1px solid #C9BBA9",
//                     fontSize: 17,
//                     color: "#2E2A24",
//                   }}
//                 />
//               </div>

//               <div>
//                 <label className="tracked" style={{ fontSize: 11, color: "#8C6A34", textTransform: "uppercase" }}>
//                   Your Relation
//                 </label>
//                 <select
//                   value={wishForm.relation}
//                   onChange={(e) => setWishForm({ ...wishForm, relation: e.target.value })}
//                   style={{
//                     width: "100%",
//                     marginTop: 10,
//                     padding: "12px 2px",
//                     background: "transparent",
//                     border: "none",
//                     borderBottom: "1px solid #C9BBA9",
//                     fontSize: 16,
//                     color: "#2E2A24",
//                     cursor: "pointer",
//                   }}
//                 >
//                   {RELATION_OPTIONS.map((r) => (
//                     <option key={r} value={r}>
//                       {r}
//                     </option>
//                   ))}
//                 </select>
//               </div>

//               <div>
//                 <label className="tracked" style={{ fontSize: 11, color: "#8C6A34", textTransform: "uppercase" }}>
//                   Your Wishes
//                 </label>
//                 <textarea
//                   required
//                   rows={3}
//                   value={wishForm.message}
//                   onChange={(e) => setWishForm({ ...wishForm, message: e.target.value })}
//                   style={{
//                     width: "100%",
//                     marginTop: 10,
//                     padding: "12px 2px",
//                     background: "transparent",
//                     border: "none",
//                     borderBottom: "1px solid #C9BBA9",
//                     fontSize: 16,
//                     color: "#2E2A24",
//                     resize: "vertical",
//                     fontFamily: "inherit",
//                   }}
//                 />
//               </div>

//               <button
//                 type="submit"
//                 className="tracked"
//                 style={{
//                   marginTop: 14,
//                   background: "#8C6A34",
//                   border: "1px solid #8C6A34",
//                   color: "#FBF7F1",
//                   padding: "16px",
//                   fontSize: 12,
//                   textTransform: "uppercase",
//                   cursor: "pointer",
//                   transition: "opacity 0.4s ease",
//                 }}
//                 onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.85")}
//                 onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
//               >
//                 Send Wishes
//               </button>
//             </form>
//           </Reveal>

//           {wishes.length > 0 && (
//             <Reveal>
//               <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 28 }}>
//                 <p className="tracked" style={{ fontSize: 11, color: "#8C6A34", textTransform: "uppercase" }}>
//                   {wishes.length} {wishes.length === 1 ? "Wish" : "Wishes"} So Far
//                 </p>
//                 <button
//                   onClick={exportWishesToExcel}
//                   className="tracked"
//                   style={{
//                     background: "transparent",
//                     border: "1px solid #8C6A34",
//                     color: "#8C6A34",
//                     padding: "9px 18px",
//                     fontSize: 10,
//                     textTransform: "uppercase",
//                     cursor: "pointer",
//                     transition: "all 0.4s ease",
//                   }}
//                   onMouseEnter={(e) => {
//                     e.currentTarget.style.background = "#8C6A34";
//                     e.currentTarget.style.color = "#F3EBE1";
//                   }}
//                   onMouseLeave={(e) => {
//                     e.currentTarget.style.background = "transparent";
//                     e.currentTarget.style.color = "#8C6A34";
//                   }}
//                 >
//                   Export to Excel
//                 </button>
//               </div>

//               <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
//                 {wishes.map((w, i) => (
//                   <div
//                     key={i}
//                     style={{
//                       padding: "24px 0",
//                       borderBottom: i < wishes.length - 1 ? "1px solid #E7D6CC" : "none",
//                     }}
//                   >
//                     <p style={{ fontSize: 16, lineHeight: 1.8, color: "#2E2A24", fontWeight: 300, marginBottom: 10 }}>
//                       "{w.message}"
//                     </p>
//                     <p className="tracked" style={{ fontSize: 11, color: "#B9925A", textTransform: "uppercase" }}>
//                       {w.name} {w.relation ? `· ${w.relation}` : ""}
//                     </p>
//                   </div>
//                 ))}
//               </div>
//             </Reveal>
//           )}
//         </div>
//       </section>

//       {/* ---------------- FINAL ---------------- */}
//       <section
//         style={{
//           minHeight: "80vh",
//           display: "flex",
//           flexDirection: "column",
//           alignItems: "center",
//           justifyContent: "center",
//           textAlign: "center",
//           padding: "100px 6vw",
//           background: "radial-gradient(ellipse at 50% 100%, #F3EBE1 0%, #FBF7F1 60%)",
//         }}
//       >
//         <Reveal>
//           <h2 className="serif" style={{ fontSize: "clamp(40px, 8vw, 90px)", fontWeight: 400, margin: 0 }}>
//             Yomna <span style={{ color: "#B9925A", fontStyle: "italic" }}>&amp;</span> Ahmed
//           </h2>
//         </Reveal>
//         <Reveal delay={0.15}>
//           <p className="serif" style={{ fontSize: "clamp(18px, 2.4vw, 26px)", fontStyle: "italic", color: "#8C6A34", margin: "24px 0" }}>
//             Forever begins here.
//           </p>
//         </Reveal>
//         <Reveal delay={0.3}>
//           <Ornament style={{ width: 180, height: 30, color: "#B9925A", margin: "18px auto" }} />
//         </Reveal>
//         <Reveal delay={0.4}>
//           <p className="tracked" style={{ fontSize: 13, color: "#6B6255" }}>
//             15 &middot; October &middot; 2026
//           </p>
//         </Reveal>
//       </section>

//       <footer style={{ textAlign: "center", padding: "36px 6vw", borderTop: "1px solid #E7D6CC" }}>
//         <p className="tracked" style={{ fontSize: 10, color: "#B9925A", textTransform: "uppercase" }}>
//           With love, Yomna &amp; Ahmed
//         </p>
//       </footer>
//     </div>
//   );
// }
